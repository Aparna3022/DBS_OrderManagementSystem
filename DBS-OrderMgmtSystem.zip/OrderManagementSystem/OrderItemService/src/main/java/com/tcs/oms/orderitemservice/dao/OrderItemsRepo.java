package com.tcs.oms.orderitemservice.dao;

import com.tcs.oms.model.order.Order;
import com.tcs.oms.model.order.OrderItem;
import com.tcs.oms.model.order.wrapper.OrderItemList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface OrderItemsRepo extends CrudRepository<OrderItem, Integer> {

    @Query("select a from com.tcs.oms.model.order.OrderItem a  where a.orderId=?1")
    public List<OrderItem> findByOrderId( Integer orderId);


}