package com.tcs.oms.orderitemservice.controller;

import com.tcs.oms.model.order.OrderItem;
import com.tcs.oms.model.order.wrapper.OrderItemList;
import com.tcs.oms.orderitemservice.dao.OrderItemsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/OrderItem")
public class OrderItemController {

    @Autowired
    OrderItemsRepo orderItemsRepo;

    @PostMapping("/save")
    public List<OrderItem> createOrderItems(@RequestBody List<OrderItem> orderItems) {
        List<OrderItem> orderItemsList = new ArrayList<>();
        orderItems.stream().forEach(orderItem->{
            System.out.println(orderItem);
            orderItemsList.add(orderItemsRepo.save(orderItem));
        });
        return orderItemsList;
    }

    @GetMapping("/get/{orderId}")
    public List<OrderItem> getOrderItems(@PathVariable("orderId") Integer orderId) {
        List<OrderItem> orderItemsList = new ArrayList<>();
        return  orderItemsRepo.findByOrderId(orderId);

    }
}
