package com.tcs.oms.orderitemservice.exception;

public class OrderItemNotFoundException extends Exception{
    public OrderItemNotFoundException(String message) {
        super(message);
    }
}
