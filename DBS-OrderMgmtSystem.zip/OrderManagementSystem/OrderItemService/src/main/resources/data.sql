insert into ADDRESS
values ('ADDID1','Dummy1Add1','Dummy1Add2','Dummy1Add3','Dummy1Add4','Dummy1City','Dummy1State','Dummy1Country','000000');
insert into ADDRESS
values ('ADDID2','Dummy2Add1','Dummy2Add2','Dummy2Add3','Dummy2Add4','Dummy2City','Dummy2State','Dummy2Country','111111');

insert into CUSTOMER values ('CUST1','NAMEDUMMY1','CUST1@DPP.com');
insert into CUSTOMER values ('CUST2','NAMEDUMMY2','CUST2@DPP.com');

insert into  CUSTOMER_ADDRESS_MAPPING values('CUST1','ADDID1');
insert into  CUSTOMER_ADDRESS_MAPPING values('CUST2','ADDID2');