package com.tcs.oms.model.order;

//import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.tcs.oms.model.customer.Address;
import com.tcs.oms.model.customer.Customer;
import com.tcs.oms.model.order.wrapper.OrderItemList;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Data
@Entity(name = "ORDERS")
@NoArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ORDER_ID")
    private Integer  orderId;

    @Column(name="CUSTOMER_ID")
    @NotBlank(message = "customerId is mandatory")
    private String customerId;

    @Column(name="ORDER_DATE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    @NotNull(message = "ORDER_DATE is mandatory")
    private Date orderDate;


    @Column(name="ADDRESS_ID")
    @NotBlank(message = "addressId is mandatory")
    private String addressId;

    @Transient
    @JsonProperty("orderItemList")
    @NotNull(message = "OrderItem is mandatory")
    private List<OrderItem> orderItemList;

/*
    @OneToMany(mappedBy="order")
    private List<OrderItem> orderItems;
*/


    @Column(name="TOTAL_PRICE")
    private Float  totalPrice;

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customerId='" + customerId + '\'' +
                ", orderDate=" + orderDate +
                ", addressId='" + addressId + '\'' +
                ", orderItemList=" + orderItemList +
                ", totalPrice=" + totalPrice +
                '}';
    }
}
