package com.tcs.oms.model.customer;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name ="CUSTOMER_ADDRESS_MAPPING" )
@IdClass(CustomerAddressId.class)
public class CustomerAddressMapping {

    @Id
    @Column(name="CUSTOMER_ID")
    private String customerId;

    @Id
    @Column(name="ADDRESS_ID")
    private String addressId;
}
