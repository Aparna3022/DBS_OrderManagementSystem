package com.tcs.oms.model.order.wrapper;

import com.tcs.oms.model.order.OrderItem;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class OrderItemList {

    List<OrderItem> orderItemList;
}
