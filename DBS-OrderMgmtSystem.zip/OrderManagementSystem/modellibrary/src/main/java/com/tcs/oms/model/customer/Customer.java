package com.tcs.oms.model.customer;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity(name = "CUSTOMER")
public class Customer {

    @Id
    @Column(name="CUSTOMER_ID")
    private String customerId;
    @Column(name="CUSTOMER_NAME")
    private String customerName;
    @Column(name="CUSTOMER_EMAIL")
    private String customerAddress;
}
