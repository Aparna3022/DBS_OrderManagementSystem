package com.tcs.oms.model.customer;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
@Entity(name = "ADDRESS")
public class Address {

    @Id
    @Column(name="ADDRESS_ID")
    private String  addressId;
    @Column(name="ADDRESS_1")
    private String address1;
    @Column(name="ADDRESS_2")
    private String address2;
    @Column(name="ADDRESS_3")
    private String address3;
    @Column(name="ADDRESS_4")
    private String address4;
    @Column(name="CITY")
    private String city;
    @Column(name="STATE")
    private String state;
    @Column(name="COUNTRY")
    private String country;
    @Column(name="PINCODE")
    private String pincode;
}
