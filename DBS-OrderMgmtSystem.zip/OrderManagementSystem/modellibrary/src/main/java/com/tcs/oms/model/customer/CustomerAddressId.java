package com.tcs.oms.model.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.bytebuddy.asm.Advice;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
import java.io.Serializable;


@Data
@AllArgsConstructor
public class CustomerAddressId  implements Serializable {

    private String customerId;

    private String addressId;


}
