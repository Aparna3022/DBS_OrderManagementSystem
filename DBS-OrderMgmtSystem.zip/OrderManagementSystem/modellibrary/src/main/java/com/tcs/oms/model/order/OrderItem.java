package com.tcs.oms.model.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;

@Data
@Entity(name = "ORDER_ITEM")
@NoArgsConstructor
public class OrderItem {

    public OrderItem(String productCode, String productName, Integer quantity, Integer orderId) {
        this.productCode = productCode;
        this.productName = productName;
        this.quantity = quantity;
        this.orderId = orderId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="ORDER_ITEM_ID")
    private Integer  orderItemId;
    @Column(name="PRODUCT_CODE")
    private String productCode;
    @Column(name="PRODUCT_NAME")
    private String productName;
    @Column(name="QUANTITY")
    private Integer quantity;
    @Column(name="ORDER_ID")
    private Integer  orderId;
/*    @ManyToOne
    @JoinColumn(name="ORDER_ID", nullable=false)
    private Order order;*/

    @Override
    public String toString() {
        return "OrderItem{" +
                "orderItemId=" + orderItemId +
                ", productCode='" + productCode + '\'' +
                ", productName='" + productName + '\'' +
                ", quantity=" + quantity +

                '}';
    }
}
