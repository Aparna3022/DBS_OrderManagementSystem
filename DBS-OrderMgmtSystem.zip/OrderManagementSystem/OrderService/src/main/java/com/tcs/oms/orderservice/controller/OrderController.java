package com.tcs.oms.orderservice.controller;

import com.tcs.oms.model.order.Order;
import com.tcs.oms.model.order.OrderItem;
import com.tcs.oms.model.order.wrapper.OrderItemList;
import com.tcs.oms.orderservice.dao.OrderRepo;
import com.tcs.oms.orderservice.exception.OrderNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/Order")
public class OrderController {

    @Autowired
    OrderRepo orderRepo;

    @Autowired
    OrderItemServiceFeignClient orderItemServiceFeignClient;

    @PostMapping("/create")
    public Order createOrder(@Valid  @RequestBody Order order) {
        final Order savedOrder = orderRepo.save(order);

        List<OrderItem> decoratedOrderItem = order.getOrderItemList().stream()
                .map(orderItem  -> {return (new OrderItem(orderItem.getProductCode(),orderItem.getProductName(),orderItem.getQuantity(),savedOrder.getOrderId()));})
                .collect(Collectors.toList());
        orderItemServiceFeignClient.saveOrderItems(decoratedOrderItem);
        return savedOrder;
    }

    @GetMapping("/retrieve")
    public Order retrieveOrder(@RequestParam Integer orderId) throws OrderNotFoundException {
        final Optional<Order> savedOrder = orderRepo.findById(orderId);
        boolean present = savedOrder.isPresent();
        Order order;
        if(present) {
            order = savedOrder.get();
            List<OrderItem> orderItems = orderItemServiceFeignClient.getOrderItems(orderId);
            order.setOrderItemList(orderItems);
            return order;
        }
        else{
            throw new OrderNotFoundException(String.format("Order Not Found for %s", orderId));
        }

    }
}
