package com.tcs.oms.orderservice.controller;

import com.tcs.oms.model.order.OrderItem;
import com.tcs.oms.model.order.wrapper.OrderItemList;

import feign.RequestLine;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(url = "http://localhost:8086/OrderItem" ,name="OrderItemService" )
public interface OrderItemServiceFeignClient {

    @PostMapping("/save")
    public void saveOrderItems(List<OrderItem> orderItemList);


    @RequestMapping(value = "/get/{orderId}", method = RequestMethod.GET)
    public List<OrderItem> getOrderItems(@PathVariable("orderId") Integer orderId);
}
