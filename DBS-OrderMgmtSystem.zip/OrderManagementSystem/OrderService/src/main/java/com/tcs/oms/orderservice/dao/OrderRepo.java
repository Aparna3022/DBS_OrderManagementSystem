package com.tcs.oms.orderservice.dao;

import com.tcs.oms.model.customer.Customer;
import com.tcs.oms.model.order.Order;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface OrderRepo extends CrudRepository<Order, Integer> {
	/*List<Order> findByCustomer(Customer customer);*/

}